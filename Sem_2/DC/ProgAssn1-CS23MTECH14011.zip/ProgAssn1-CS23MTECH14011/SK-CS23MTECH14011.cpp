#include <zmq.hpp>
#include <iostream>
#include <thread>
#include <vector>
#include <chrono>
#include <random>
#include <ctime>
#include <mutex>
#include <fstream>

using namespace std;

// Constants
#define PORT 10000

// Global Variables
tm *local_time;
time_t current_time;
int num_processes, lambda, max_messages;
double alpha;
std::vector<std::vector<int>> communication_graph;
std::ofstream logfile;
std::mutex mtx;
int messages_received = 0;
int total_message_size = 0;

// Function Declarations
double generate_exponential_random(double lambda);
void update_vector_clock(std::vector<int> &vc, int event, int pid, int pid2, std::vector<int> &ls, std::vector<int> &lu, int vec_tuple_recv[100][2]);
void display_vector_clock(const std::vector<int> &vc);
void receive(zmq::socket_t &socket, int pid, std::vector<int> &vc, std::vector<int> &ls, std::vector<int> &lu);
void send(zmq::socket_t &socket, int pid, std::vector<int> &vc, std::vector<int> &ls, std::vector<int> &lu, int message, int pid2);
void event(zmq::socket_t &socket, int pid, std::vector<int> &vc, std::vector<int> &ls, std::vector<int> &lu);
void process(int id);

// Generate exponential random number
double generate_exponential_random(double lambda) {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::exponential_distribution<double> distribution(lambda);
    return distribution(gen);
}

// Update vector clock
void update_vector_clock(std::vector<int> &vc, int event, int pid, int pid2, std::vector<int> &ls, std::vector<int> &lu, int vec_tuple_recv[100][2]={0}) {
    vc[pid] = vc[pid] + 1;
    lu[pid] = vc[pid];

    if (event == 2) {
        for (int i = 1; i < num_processes + 1; ++i) {
            if (vec_tuple_recv[i][0] >= 0) {
                int index = vec_tuple_recv[i][0];
                int value = vec_tuple_recv[i][1];
                if (vc[index] < value) {
                    vc[index] = value;
                    lu[index] = vc[pid];
                }
            }
            else
                break;
        }
    }
}

// Display vector clock
void display_vector_clock(const std::vector<int> &vc) {
    logfile << "[ ";
    for (auto &i : vc)
        logfile << i << " ";
    logfile << "]\n";
}

// Receive function
void receive(zmq::socket_t &socket, int pid, std::vector<int> &vc, std::vector<int> &ls, std::vector<int> &lu) {
    zmq::message_t received_message;
    while (messages_received < max_messages * num_processes) {
        zmq::recv_result_t result;
        result = socket.recv(received_message, zmq::recv_flags::none);
        std::string message = std::string(static_cast<char*>(received_message.data()), received_message.size());
        int recv_int[100][2];
        sscanf(message.c_str(), "%d %d", &recv_int[0][0], &recv_int[0][1]);
        for (int i = 1; i < num_processes + 1; ++i) {
            recv_int[i][0] = -1;
            recv_int[i][1] = -1;
        }

        int message_number = recv_int[0][0];
        int pid2 = recv_int[0][1];
        update_vector_clock(vc, 2, pid, pid2, ls, lu, recv_int);

        int message_size = received_message.size();

        mtx.lock();
        current_time = time(0);
        local_time = localtime(&current_time);
        messages_received = messages_received + 1;
        logfile << "Process " << pid << " receives message m" << pid2 << message_number << " from process " << pid2 << " at " << local_time->tm_hour << ":" << local_time->tm_min << ", vc: ";
        display_vector_clock(vc);
        cout << "Received Message size: " << message_size << " bytes\n"; // Print message size
        mtx.unlock();
    }
}

// Send function
void send(zmq::socket_t &socket, int pid, std::vector<int> &vc, std::vector<int> &ls, std::vector<int> &lu, int message, int pid2) {
    std::string message_str = std::to_string(message) + " " + std::to_string(pid2);
    socket.send(zmq::buffer(message_str));

    std::vector<int> update;
    for (int k = 0; k < lu.size(); ++k) {
        if (lu[k] > ls[pid])
            update.push_back(k);
    }

    mtx.lock();
    total_message_size += (update.size() + 1) * 2;
    mtx.unlock();
}

// Event function
void event(zmq::socket_t &socket, int pid, std::vector<int> &vc, std::vector<int> &ls, std::vector<int> &lu) {
    int internal = 0, message = 0;
    double sleep;
    double total_events = max_messages * (alpha + 1);
    int turn = -1;
    int choice;

    for (int i = 0; i < ceil(total_events); ++i) {
        choice = rand() % 3;
        if (((choice == 0 || choice == 1) && internal < max_messages * alpha) || message == max_messages) {
            update_vector_clock(vc, 0, pid, pid, ls, lu);
            internal++;

            mtx.lock();
            current_time = time(0);
            local_time = localtime(&current_time);
            logfile << "Process " << pid << " executes internal event e" << pid << internal << " at " << local_time->tm_hour << ":" << local_time->tm_min << ", vc: ";
            display_vector_clock(vc);
            mtx.unlock();

            sleep = generate_exponential_random(lambda);
            std::this_thread::sleep_for(std::chrono::milliseconds(static_cast<int>(sleep)));
        } else {
            turn = (turn + 1) % communication_graph[pid].size();
            int pid2 = communication_graph[pid][turn];

            update_vector_clock(vc, 1, pid, pid2, ls, lu);
            message++;

            mtx.lock();
            current_time = time(0);
            local_time = localtime(&current_time);
            logfile << "Process " << pid << " sends message m" << pid << message << " to process " << pid2 << " at " << local_time->tm_hour << ":" << local_time->tm_min << ", vc: ";
            display_vector_clock(vc);
            mtx.unlock();

            send(socket, pid2, vc, ls, lu, message, pid);
            ls[pid2] = vc[pid];
            sleep = generate_exponential_random(lambda);
            std::this_thread::sleep_for(std::chrono::milliseconds(static_cast<int>(sleep)));
        }
    }
}

// Main process function
void process(int id) {
    zmq::context_t context(1);
    zmq::socket_t socket(context, ZMQ_PAIR);

    if (id == 0) {
        socket.bind("tcp://127.0.0.1:" + to_string(PORT));
    } else {
        socket.connect("tcp://127.0.0.1:" + to_string(PORT));
    }

    std::vector<int> vc(num_processes, 0);
    std::vector<int> ls(num_processes, 0);
    std::vector<int> lu(num_processes, 0);

    event(socket, id, vc, ls, lu);
    receive(socket, id, vc, ls, lu);
}

int main() {
    std::ifstream in("inp-params.txt");
    logfile.open("log-SK.txt");

    if (in.is_open()) {
        in >> num_processes >> lambda >> alpha >> max_messages;
        communication_graph.resize(num_processes);
        for (int i = 0; i < num_processes; ++i) {
            int vertex, edges;
            in >> vertex >> edges;

            for (int j = 0; j < edges; ++j) {
                int v2;
                in >> v2;
                communication_graph[vertex].push_back(v2);
            }
        }

        std::vector<std::thread> threads(num_processes);
        for (int id = 0; id < num_processes; ++id) {
            threads[id] = std::thread(process, id);
        }

        for (int id = 0; id < num_processes; ++id) {
            threads[id].join();
        }
    }

    logfile.close();
    return 0;
}
