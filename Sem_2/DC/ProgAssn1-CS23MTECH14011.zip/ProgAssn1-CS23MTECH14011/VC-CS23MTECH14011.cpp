#include <iostream>
#include <fstream>
#include <thread>
#include <vector>
#include <zmq.hpp>
#include <random>
#include <mutex>
#include <unistd.h>
#include <ctime>

using namespace std;

// Constants
#define PORT 50000

// Global Variables
tm *local_time;
time_t current_time;
int num_processes, lambda, max_messages;
double alpha;
vector<vector<int>> communication_graph;
FILE *log_file;
mutex mtx;
int messages_received = 0;

// Generate random numbers following an exponential distribution
double generate_exponential_random(double lambda) {
    default_random_engine generator;
    exponential_distribution<double> distribution(lambda);
    return distribution(generator);
}

// Update the vector clock
void update_vector_clock(vector<int> &vc, int event, int process_id, const vector<int> &recv_vc = vector<int>()) {
    vc[process_id] = vc[process_id] + 1;
    if (event == 2) {
        for (int i = 0; i < vc.size(); ++i)
            if (vc[i] < recv_vc[i]) vc[i] = recv_vc[i];
    }
}

// Display the vector clock
void display_vector_clock(vector<int> &vc) {
    fprintf(log_file, "[ ");
    for (auto &i : vc)
        fprintf(log_file, "%d ", i);
    fprintf(log_file, "]\n");
}

// Send message to another process
void send_message(zmq::socket_t &socket, int sender_pid, vector<int> &msg) {
    zmq::message_t zmq_msg(sizeof(int) * (msg.size() + 2));
    memcpy(zmq_msg.data(), msg.data(), sizeof(int) * msg.size());
    zmq_msg.data<int>()[msg.size()] = messages_received + 1;
    zmq_msg.data<int>()[msg.size() + 1] = getpid();
    socket.send(zmq_msg, zmq::send_flags::none);
}

// Process events in a process
void process_event(zmq::socket_t &socket, int process_id, vector<int> &vc) {
    int internal_events = 0, message_events = 0;
    double total_events = max_messages * (alpha + 1);
    int turn = -1;
    int choice;

    for (int i = 0; i < total_events; ++i) {
        choice = rand() % 3;

        if (((choice == 0 || choice == 1) && internal_events < max_messages * alpha) || message_events == max_messages) {
            // Internal event
            update_vector_clock(vc, 0, process_id);
            internal_events++;

            mtx.lock();
            current_time = time(0);
            local_time = localtime(&current_time);
            fprintf(log_file, "Process%d executes internal event e%d%d at %d:%d, vc: ", process_id, process_id, internal_events, local_time->tm_hour,
                    local_time->tm_min);
            display_vector_clock(vc);
            mtx.unlock();

            usleep(generate_exponential_random(lambda) * 1000);
        } else {
            // Message send event
            turn = (turn + 1) % communication_graph[process_id].size();
            int receiver_pid = communication_graph[process_id][turn];

            update_vector_clock(vc, 1, process_id);
            message_events++;

            mtx.lock();
            current_time = time(0);
            local_time = localtime(&current_time);
            fprintf(log_file, "Process%d sends message m%d%d to process%d at %d:%d, vc: ", process_id, process_id, message_events, receiver_pid,
                    local_time->tm_hour, local_time->tm_min);
            display_vector_clock(vc);
            vector<int> msg(vc.begin(), vc.end());
            send_message(socket, receiver_pid, msg);
            mtx.unlock();

            usleep(generate_exponential_random(lambda) * 1000);
        }
    }
}

// Receive messages in a process
void receive_messages(zmq::socket_t &socket, int process_id, vector<int> &vc) {
    zmq::message_t zmq_msg;
    while (messages_received < max_messages) {
        zmq::recv_result_t result;
        result = socket.recv(zmq_msg, zmq::recv_flags::none);
        vector<int> received_msg(static_cast<int *>(zmq_msg.data()), static_cast<int *>(zmq_msg.data()) + zmq_msg.size() / sizeof(int));
        int message_number = received_msg[num_processes];
        int sender_pid = received_msg[num_processes + 1];

        vector<int> received_vc(received_msg.begin(), received_msg.begin() + num_processes);
        update_vector_clock(vc, 2, process_id, received_vc);

        int message_size = zmq_msg.size();

        mtx.lock();
        current_time = time(0);
        local_time = localtime(&current_time);
        messages_received++;
        fprintf(log_file, "Process%d receives m%d%d from process%d at %d:%d, vc: ", process_id, sender_pid, message_number, sender_pid,
                local_time->tm_hour, local_time->tm_min);
        display_vector_clock(vc);
        cout << "Received Message size: " << message_size << " bytes\n"; // Print message size
        mtx.unlock();
    }
}

// Main function
void process(int process_id) {
    // Create a ZeroMQ context
    zmq::context_t context(1);
    // Create a ZeroMQ socket
    zmq::socket_t socket(context, ZMQ_PAIR);
    // Connect to the socket

    if(process_id == 0) {
        socket.bind("tcp://127.0.0.1:" + to_string(PORT));
    } else {
        socket.connect("tcp://127.0.0.1:" + to_string(PORT));
    }
    // Initialize vector clock
    vector<int> vc(num_processes, 0);

    // Create threads for event handling and message receiving
    thread event_thread(process_event, ref(socket), process_id, ref(vc));
    thread receive_thread(receive_messages, ref(socket), process_id, ref(vc));

    // Join the threads to wait for their completion
    event_thread.join();
    receive_thread.join();
}

int main() {
    // Read parameters from file
    ifstream file("inp-params.txt");
    log_file = fopen("log-VC.txt", "w+");
    if (file.is_open()) {
        file >> num_processes >> lambda >> alpha >> max_messages;
        communication_graph.resize(num_processes);
        for (int i = 0; i < num_processes; ++i) {
            int vertex, edges;
            file >> vertex >> edges;
            for (int j = 0; j < edges; ++j) {
                int neighbor;
                file >> neighbor;
                communication_graph[vertex].push_back(neighbor);
            }
        }

        // Start a process for each node
        vector<thread> threads;
        for (int id = 0; id < num_processes; ++id) {
            threads.emplace_back(process, id);
        }

        // Wait for all threads to finish
        for (auto &thread : threads) {
            thread.join();
        }
    }
    fclose(log_file);
    
    return 0;
}
