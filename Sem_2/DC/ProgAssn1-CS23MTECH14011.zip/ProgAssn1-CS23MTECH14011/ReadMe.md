## Prerequisites

- Linux system (Installation/ set-up of ZMQ in Windows is not mentioned in documentation and causes issues)
- ZMQ installed (refer to ZMQ guide for C++ ZMQ library installation)

## Submission Set-Up

1. Download and unzip the submitted zip file.
2. Open terminal inside the folder.

## Compilation

Use the following commands to compile the code:

```bash
g++ -fdiagnostics-color=always -g VC-CS23MTECH14011.cpp -o VC -lzmq
g++ -fdiagnostics-color=always -g SK-CS23MTECH14011.cpp -o SK -lzmq
```
Upon completion of compilation, two executable files will be generated, namely `SK` and `VC`.

## Execution

Use the following commands to tun the executable the code:

```bash
./VC
./SK
```
Upon completion of execution, log files will be generated: `log-vc.txt` and `log-sk.txt`.

Use the following commands to view  the log files in terminal: 

```bash
cat log-vc.txt
cat log-sk.txt
```

