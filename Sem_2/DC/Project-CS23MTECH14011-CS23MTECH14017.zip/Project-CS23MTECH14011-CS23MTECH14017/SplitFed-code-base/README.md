## Description

This repository contains the implementation of Centralized Learning (baseline), Federated Learning, Split Learning, SplitFedV1 Learning and SplitFedV2 Learning.

All programs are written in python 3.7.2 using the PyTorch library (PyTorch 1.2.0).

Dataset: HAM10000 

Refer this link to download the dataset - https://www.kaggle.com/datasets/kmader/skin-cancer-mnist-ham10000
The files of the zipped dataset must be extracted in a directory named 'data'. Please refer image.png to view the correct directory-tree structure.
