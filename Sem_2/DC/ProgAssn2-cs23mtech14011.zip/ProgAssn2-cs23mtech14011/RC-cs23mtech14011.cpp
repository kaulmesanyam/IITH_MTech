#include <iostream>
#include <thread>
#include <mutex>
#include <chrono>
#include <random>
#include <vector>
#include <atomic>
#include <condition_variable>
#include <cstring>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unordered_set>
#include <fstream>
#include <queue> // For message queue

using namespace std;

// Parameters
int n = 0; // Number of processes (perfect square)
int k = 0;  // Number of times each process enters CS
double alpha = 0; // Average time for local computation
double beta = 0;  // Average time spent inside CS

// Mutex for critical section
mutex mtx;

// Condition variable for signaling CS entry
condition_variable cv;

// Flag indicating CS entry permission
bool cs_permitted = false;

// Structure for message
struct Message {
    int type; // 0 for REQUEST, 1 for REPLY, 2 for RELEASE
    int pid;  // Process ID
    chrono::system_clock::time_point timestamp; // Timestamp
};

// Function to simulate exponential distribution with average avg
double exponential(double avg) {
    random_device rd;
    mt19937 gen(rd());
    exponential_distribution<double> dist(1.0 / avg);
    return dist(gen);
}

// Function representing local computation of process
void local_computation(int pid, vector<int> &sock_fd, ofstream &logfile) {
    int outCSTime, inCSTime;
    vector<Message> msg_buffer(n);

    // Execute until the termination condition is reached
    for (int i = 0; i < k; ++i) {
        outCSTime = exponential(alpha) * 1000; // Convert to milliseconds
        inCSTime = exponential(::beta) * 1000;   // Convert to milliseconds

        // Local computation
        auto local_start = chrono::system_clock::now();
        this_thread::sleep_for(chrono::milliseconds(outCSTime));
        auto local_end = chrono::system_clock::now();

        // Log local computation
        logfile << "Process " << pid << " is doing local computation at " << chrono::system_clock::to_time_t(local_start) << endl;

        // Requesting CS
        Message req_msg;
        req_msg.type = 0; // REQUEST
        req_msg.pid = pid;
        req_msg.timestamp = chrono::system_clock::now();
        for (int j = 0; j < n; ++j) {
            if (j != pid) {
                sendto(sock_fd[j], &req_msg, sizeof(req_msg), 0, nullptr, 0);
                logfile << "Process " << pid << " sent REQUEST to Process " << j << " at " << chrono::system_clock::to_time_t(req_msg.timestamp) << endl;
            }
        }

        // Waiting for permission to enter CS
        unique_lock<mutex> lk(mtx);
        cv.wait(lk, [&] { return cs_permitted; });
        cs_permitted = false;
        lk.unlock();

        // Inside CS
        auto cs_start = chrono::system_clock::now();
        logfile << "Process " << pid << " enters CS at " << chrono::system_clock::to_time_t(cs_start) << endl;
        this_thread::sleep_for(chrono::milliseconds(inCSTime));
        auto cs_end = chrono::system_clock::now();
        logfile << "Process " << pid << " leaves CS at " << chrono::system_clock::to_time_t(cs_end) << endl;

        // Releasing CS
        lk.lock();
        for (int j = 0; j < n; ++j) {
            if (j != pid) {
                Message rel_msg;
                rel_msg.type = 2; // RELEASE
                rel_msg.pid = pid;
                rel_msg.timestamp = chrono::system_clock::now();
                sendto(sock_fd[j], &rel_msg, sizeof(rel_msg), 0, nullptr, 0);
                logfile << "Process " << pid << " sent RELEASE to Process " << j << " at " << chrono::system_clock::to_time_t(rel_msg.timestamp) << endl;
            }
        }
        lk.unlock();
    }
}

// Function to handle incoming messages
void message_handler(int pid, vector<int> &sock_fd, ofstream &logfile) {
    struct sockaddr_in serv_addr;
    socklen_t addr_len = sizeof(serv_addr);
    Message msg;

    // Create socket for communication
    sock_fd[pid] = socket(AF_INET, SOCK_DGRAM, 0);
    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    serv_addr.sin_port = htons(8080 + pid);
    bind(sock_fd[pid], (struct sockaddr *)&serv_addr, sizeof(serv_addr));

    // Handle incoming messages
    while (true) {
        recvfrom(sock_fd[pid], &msg, sizeof(msg), 0, (struct sockaddr *)&serv_addr, &addr_len);
        if (msg.type == 0) { // REQUEST
            logfile << "Process " << pid << " received REQUEST from Process " << msg.pid << " at " << chrono::system_clock::to_time_t(msg.timestamp) << endl;
            unique_lock<mutex> lk(mtx);
            if (!cs_permitted) {
                Message reply_msg;
                reply_msg.type = 1; // REPLY
                reply_msg.pid = pid;
                reply_msg.timestamp = chrono::system_clock::now();
                sendto(sock_fd[msg.pid], &reply_msg, sizeof(reply_msg), 0, nullptr, 0);
                logfile << "Process " << pid << " sent REPLY to Process " << msg.pid << " at " << chrono::system_clock::to_time_t(reply_msg.timestamp) << endl;
            }
            lk.unlock();
        } else if (msg.type == 1) { // REPLY
            logfile << "Process " << pid << " received REPLY from Process " << msg.pid << " at " << chrono::system_clock::to_time_t(msg.timestamp) << endl;
            unique_lock<mutex> lk(mtx);
            cs_permitted = true;
            cv.notify_one();
            lk.unlock();
        } else if (msg.type == 2) { // RELEASE
            logfile << "Process " << pid << " received RELEASE from Process " << msg.pid << " at " << chrono::system_clock::to_time_t(msg.timestamp) << endl;
            cv.notify_one();
        }
    }
}

int main() {
    // Open the input parameters file
    ifstream params_file("inp_params.txt");
    if (!params_file.is_open()) {
        cerr << "Error: Unable to open inp_params.txt file." << endl;
        return 1;
    }
    
    // Read parameters from file
    int loc_n, loc_k;
    double a, b;
    if (!(params_file >> loc_n >> loc_k >> a >> b)) {
        cerr << "Error: Unable to read parameters from inp_params.txt file." << endl;
        return 1;
    }
    params_file.close();
    n = loc_n;
    k = loc_k;
    alpha = a;
    ::beta = b;
    cout << "Read parameters: n = " << loc_n << ", k = " << loc_k << ", alpha = " << a << ", beta = " << b << endl;

    ofstream logfile("RC-logfile.txt");
    vector<thread> processes;
    vector<int> sock_fd(n);

    // Create threads for processes
    for (int i = 0; i < n; ++i) {
        processes.push_back(thread(local_computation, i, ref(sock_fd), ref(logfile)));
        processes.push_back(thread(message_handler, i, ref(sock_fd), ref(logfile)));
    }

    // Join threads
    for (auto &t : processes) {
        t.join();
    }

    return 0;
}
