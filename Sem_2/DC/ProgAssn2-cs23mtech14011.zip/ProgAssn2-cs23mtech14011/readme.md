# Maekawa algorithm and Cauraicol & Carvalho Algorithm

## Description
This project consists of two C++ files (`M-cs23mtech14011.cpp` and `RC-cs23mtech14011.cpp`) and an input parameters file (`inp_params.txt`). The input parameters file specifies the parameters `n`, `k`, `alpha`, and `beta` in the same sequence. These parameters are read by the C++ files when they are executed.

## Usage
1. **Compilation**: 
    ```
    g++ M-cs23mtech14011.cpp -o M-cs23mtech14011 -lpthread
    g++ RC-cs23mtech14011.cpp -o RC-cs23mtech14011 -lpthread
    ```
   Replace `g++` with your preferred compiler if necessary.

2. **Execution**:
    ```
    ./M-cs23mtech14011
    ./RC-cs23mtech14011
    ```
   Make sure `inp_params.txt` exists in the directory.

## Input Parameters
The input parameters file `inp_params.txt` should contain the following parameters in the specified sequence:
- `n`: Description of parameter n.
- `k`: Description of parameter k.
- `alpha`: Description of parameter alpha.
- `beta`: Description of parameter beta.

## Log files
`M-logfile.txt` is created when `./M-cs23mtech14011` is executed. Similarly,`RC-logfile.txt` is created when `./RC-cs23mtech14011` is executed.

## Author
- Sanyam Kaul (CS23MTECH14011)
